NOREV — Modern Everyday Wear

Cara melihat:
1. Ekstrak file ZIP.
2. Buka folder norev_website.
3. Klik dua kali index.html untuk melihat website di browser.

Fitur demo:
- Homepage responsif dengan gaya minimalis premium.
- Katalog produk contoh.
- Pilihan ukuran, warna, dan jumlah.
- Add to Cart dan keranjang yang tersimpan di browser.
- Checkout via WhatsApp ke 085602048263.

Catatan:
- Foto produk menggunakan gambar eksternal Unsplash, sehingga koneksi internet diperlukan untuk menampilkannya.
- Harga, nama produk, foto, dan stok masih berupa contoh.
- Ini adalah website front-end/demo untuk UTS, belum memakai database atau dashboard admin sungguhan.
- Agar bisa diakses publik, unggah folder ini ke layanan hosting statis seperti Netlify, Vercel, atau GitHub Pages. Setelah deploy, bagikan URL publik yang diberikan layanan tersebut.
- Uji tombol WhatsApp di perangkat yang sudah memiliki WhatsApp/Web WhatsApp.


Cara membuat website publik (gratis) dengan Netlify:
1. Buka https://app.netlify.com/drop
2. Login atau daftar akun Netlify.
3. Ekstrak ZIP ini terlebih dahulu.
4. Seret folder norev_website (yang berisi index.html) ke area upload Netlify Drop.
5. Tunggu deploy selesai. Netlify akan memberikan alamat website publik berakhiran netlify.app.
6. Buka alamat tersebut untuk memastikan website tampil, lalu bagikan link itu kepada dosen.

Catatan: Saya sudah menambahkan tautan Instagram @m.irfnfardan ke footer website. Website belum otomatis online dari file ZIP; proses upload ke layanan hosting perlu dilakukan dari akun pemilik.
